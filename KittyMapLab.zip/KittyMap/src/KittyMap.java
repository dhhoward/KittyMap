import java.util.Scanner;
import static java.lang.System.*;

public class KittyMap
{
	private boolean[][] kittyGrid;

	/*
	 *this constructor loads in random true and false values
	 */
	public KittyMap(int rows, int cols)
	{
	}

	/*
	 *this method will call getKittyCountsGrid
	 *to retrieve the kitty counts for the kittyGrid
	 */
	public void printKittyCount()
	{
	}

	/*
	 *this method will calculate the kitty counts for each cell
	 *if cell is true set int value to 9
	 *if cell is not true set int value to cnt of kitties in adjacent cells
	 */
	private int[][] getKittyCountsGrid()
	{
		return null;
	}

	/*
	 *this method will return the value of the current cell
	 *if this cell contains a kitty - return 9
	 *otherwise - return the cnt of all kitties in adjacent cells
	 */
	public int getKittyCount( int r, int c)
	{
		return 0;
	}

	/*
	 *check r and c to ensure they are inside the grid
	 */
	private boolean inBounds( int r, int c)
	{
		return false;
	}

	/*
	 *return the kitty grid as a string
	 */
	public String toString()
	{
		String output="";
		return output.trim();
	}
}